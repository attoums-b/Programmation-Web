<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>


<?php
//definir les différentes informations dans un tableau 
$infos = [
"num" => "ton numero",
"prenom "=> "ton prenom",
"nom" => "ton nom"

];

// faire une boucle pour pouvoir afficher toutes les valeurs 
foreach($infos as $cle => $valeur){
    echo $cle, ": ", $valeur,"<br>";
}

?>

</body>
</html>











