<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    


<?php

$nombres = [0,1,2,3,4,5,6,7,8,9];
$nb= 3;
$nb2 = 2;
$nb3 = 5;
echo "<h1> Table de multiplication du 3 </h1>";
echo "<ul>\n";
for($i = 0; $i < count($nombres); $i++){
    echo "<li>$nb x $i =" . ($nb * $nombres[$i])."</li>";
}
echo "</ul>\n";

echo "<h1> Table de multiplication du 2 </h1>";
echo "<ul>\n";
for($i = 0; $i < count($nombres); $i++){
    echo "<li>$nb2 x $i =" . ($nb2 * $nombres[$i])."</li>";
}

echo "</ul>\n";

echo "<h1> Table de multiplication du 5 </h1>";
echo "<ul>\n";

for($i = 0; $i < count($nombres); $i++){
    echo "<li>$nb3 x $i =" . ($nb3 * $nombres[$i])."</li>";
}

echo "</ul>\n";


?>

</body>
</html>