
<?php
require("connect.php");
$connexion = mysqli_connect(SERVEUR, LOGIN, PASSE);

if (!$connexion) {
    echo "Connexion à " . SERVEUR . " impossible\n";
    exit;
}
if (!mysqli_select_db($connexion, BASE)) {
    echo "Accès à la base " . BASE . " impossible\n";
    exit;
}
echo "Connecté au SGBD MariaDB, à la base " . BASE . "\n";
mysqli_set_charset($connexion, "utf8");

$genre=$_POST['nom'];
if ($genre != null){
    echo "le genre existe bien";
}else{
    echo"le genre n'existe pas";
}



// Correction de la requête SQL

$resultat_genres=mysqli_query($connexion,"select Titre from MI0A401T_Films where Genre='$genre'");
$erreur = "";
if(!$resultat_genres){
    $erreur = mysqli_error($connexion);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if($erreur != ""){
        echo"<p>Erreurs: $erreur <p>\n";
    }else{
        echo "<h1>Films du genre". $genre."</h1>";
        echo "<p>zefhbj $genre</p>";
        echo "<ol>";
        while($genreSelect = mysqli_fetch_array($resultat_genres)){
            echo "<li>" . $genreSelect["Titre"] . "</li>\n";
        }
        echo "</ol>";

    }
    ?>
    
    
</body>
</html>
