
<?php
//definitions des variables login 
define('LOGIN',"sadia-deamess.blon"); 
define('PASSE',"Angelodebout2");
define('SERVEUR', "mi-mariadb.univ-tlse2.fr"); 
define('BASE',"24_2L2_sadia_deamess_blon"); 
?>







